<?php /* Smarty version Smarty-3.1-DEV, created on 2024-02-05 13:19:05
         compiled from "/var/www/html/admin/themes/OneEleven/templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:185530966465c0e049ee87e4-18539438%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '39039d81631c376dda3c4950925b314fef9d3e6b' => 
    array (
      0 => '/var/www/html/admin/themes/OneEleven/templates/footer.tpl',
      1 => 1707139139,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '185530966465c0e049ee87e4-18539438',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_65c0e049ef7d97_63018479',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_65c0e049ef7d97_63018479')) {function content_65c0e049ef7d97_63018479($_smarty_tpl) {?><?php if (!is_callable('smarty_function_cms_version')) include '/var/www/html/plugins/function.cms_version.php';
if (!is_callable('smarty_function_cms_versionname')) include '/var/www/html/plugins/function.cms_versionname.php';
?><footer id="oe_footer" class="cf"><div class="footer-left"><small class="copyright">Copyright &copy; <a rel="external" href="http://www.cmsmadesimple.org">CMS Made Simple&trade; <?php echo smarty_function_cms_version(array(),$_smarty_tpl);?>
 &ldquo;<?php echo smarty_function_cms_versionname(array(),$_smarty_tpl);?>
&rdquo;</a></small></div><div class="footer-right cf"><ul class="links"><li><a href="http://docs.cmsmadesimple.org/" rel="external" title="<?php echo lang('documentation');?>
"><?php echo lang('documentation');?>
</a></li><li><a href="http://forum.cmsmadesimple.org/" rel="external" title="<?php echo lang('forums');?>
"><?php echo lang('forums');?>
</a></li><li><a href="http://www.cmsmadesimple.org/about-link/" rel="external" title="<?php echo lang('about');?>
"><?php echo lang('about');?>
</a></li><li><a href="http://www.cmsmadesimple.org/about-link/about-us/" rel="external" title="<?php echo lang('team');?>
"><?php echo lang('team');?>
</a></li></ul></div></footer><?php }} ?>
