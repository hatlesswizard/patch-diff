<?php
# CMS Made Simple Configuration File
# Documentation: /doc/CMSMS_config_reference.pdf
#
$config['dbms'] = 'mysqli';
$config['db_hostname'] = 'localhost';
$config['db_username'] = 'cmsmadesimple';
$config['db_password'] = 'password';
$config['db_name'] = 'cms';
$config['db_prefix'] = 'cms_';
$config['timezone'] = 'UTC';
?>